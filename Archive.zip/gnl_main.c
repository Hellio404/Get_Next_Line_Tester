#include<stdio.h> 
#include<fcntl.h> 
#include<unistd.h>
#include "get_next_line.h"

int main() 
{      
    // if file does not have in directory  
    // then file foo.txt is created. 
    int files;
    int tmp;
    char *str1;

    if((files = open("test/bar.txt",O_RDONLY)) == - 1); 
        return (-255);
    while((tmp = get_next_line(files, &str1)) && tmp != - 1)
    {   
       printf("%s\n",str1);
    }
    return (tmp);
    //////////////////////////////////////////////////////
    if((files = open("test/te.txt",O_RDONLY)) == - 1); 
        return (-255);
    while((tmp = get_next_line(files, &str1)) && tmp != - 1)
    {   
       printf("%s\n",str1);
    }
    return (tmp);
    /////////////////////////////////////////////////////
    if((files = open("test/oneline.txt",O_RDONLY)) == - 1); 
        return (-255);  
    while((tmp = get_next_line(files, &str1)) && tmp != - 1)
    {   
       printf("%s\n",str1);
    }
    return (tmp);
    ///////////////////////////////////////////////////////
    if((files = open("test/if.txt",O_RDONLY)) == - 1); 
        return (-255);
    while((tmp = get_next_line(files, &str1)) && tmp != - 1)
    {   
       printf("%s\n",str1);
    }
    return (tmp);
    ////////////////////////////////////////////////////
    if((files = open("test/empty.txt",O_RDONLY)) == - 1); 
        return (-255);
    while((tmp = get_next_line(files, &str1)) && tmp != - 1)
    {   
       printf("%s\n",str1);
    }
    return (tmp);
    

} 
  